# simple-chat-app

Example app written for article purpose:
[How to write video chat app using webrtc and nodejs](https://tsh.io/blog/how-to-write-video-chat-app-using-webrtc-and-nodejs/)
