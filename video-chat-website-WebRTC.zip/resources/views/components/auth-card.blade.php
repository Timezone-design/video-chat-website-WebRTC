<div class="container">         
    <div class="account-wrapper">
        {{ $slot }}
    </div>
</div>
