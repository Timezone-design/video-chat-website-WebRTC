<div class="container">         
    <div class="account-wrapper">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH D:\vcam\video-chat-website-WebRTC\resources\views/components/auth-card.blade.php ENDPATH**/ ?>